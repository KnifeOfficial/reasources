FormForge pack-assets export. Extract the assets folder into config/formforge/pack-assets/ so the final path is config/formforge/pack-assets/assets/... Then run /forms pack on the server.
